import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

export interface Trip {
  _id?: string;              // optional so POST doesn't require it
  code: string;
  name: string;
  length: string;
  start: string;             // API returns string dates
  resort: string;
  perPerson: number;
  image: string;
  description: string;
}

@Injectable({
  providedIn: 'root'
})
export class TripData {

  private apiUrl = '/api/trips';

  constructor(private http: HttpClient) {}

  getTrips() {
    return of([
      {
        _id: '1',
        code: 'BEACH01',
        name: 'Beach Vacation',
        length: '5 days',
        start: '2026-04-10',
        resort: 'Sunny Cove Resort',
        perPerson: 1200,
        image: 'assets/images/sea.jpg',
        description: 'Relaxing beach getaway with ocean views.'
      },
      {
        _id: '2',
        code: 'MTN02',
        name: 'Mountain Adventure',
        length: '7 days',
        start: '2026-05-15',
        resort: 'High Peak Lodge',
        perPerson: 1500,
        image: 'assets/images/mountain.jpg',
        description: 'Outdoor hiking and mountain scenery.'
      }
    ]);
  }

  getTripByCode(tripCode: string) {
    return this.http.get<Trip>(`${this.apiUrl}/${tripCode}`);
  }

  addTrip(trip: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.apiUrl, trip);
  }

  updateTrip(id: string, trip: Trip): Observable<Trip> {
    return this.http.put<Trip>(`${this.apiUrl}/${id}`, trip);
  }

  deleteTrip(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}