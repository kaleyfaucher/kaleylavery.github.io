import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { TripData, Trip } from '../services/trip-data';

@Component({
  selector: 'app-trip-edit',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './trip-edit.html',
  styleUrls: ['./trip-edit.css']   // <-- plural (Angular expects this)
})
export class TripEdit implements OnInit {
  tripCode = '';
  trip: Trip | null = null;

  loading = true;
  saving = false;
  error: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private tripService: TripData
  ) {}

  ngOnInit(): void {
  console.log('TripEdit ngOnInit fired');

  this.loading = true;
  this.error = null;

  const code = this.route.snapshot.paramMap.get('tripCode');

  if (!code) {
    this.error = 'Missing trip code in URL.';
    this.loading = false;
    return;
  }

  this.tripCode = code;

  this.tripService.getTripByCode(this.tripCode).subscribe({
    next: (data) => {
      console.log('Trip loaded:', data);
      this.trip = data;
      this.loading = false;
    },
    error: (err) => {
      console.error('Trip load error:', err);
      this.error = `Failed to load trip. Status: ${err?.status ?? 'unknown'}`;
      this.loading = false;
    }
  });
}

  save(): void {
    if (!this.trip?._id) {
      this.error = 'Trip is missing _id (cannot update).';
      return;
    }

    this.saving = true;
    this.error = null;

    this.tripService.updateTrip(this.trip._id, this.trip).subscribe({
      next: () => {
        this.saving = false;
        this.router.navigate(['/trips']);
      },
      error: (err) => {
        console.error('Update error:', err);
        this.error = `Failed to update trip. Status: ${err?.status ?? 'unknown'}`;
        this.saving = false;
      }
    });
  }

  cancel(): void {
    this.router.navigate(['/trips']);
  }
}