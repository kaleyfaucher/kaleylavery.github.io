import { Routes } from '@angular/router';
import { TripList } from './trip-list/trip-list';
import { TripAdd } from './trip-add/trip-add';
import { TripEdit } from './trip-edit/trip-edit';
import { Login } from './login/login';

export const routes: Routes = [
  { path: '', redirectTo: 'trips', pathMatch: 'full' },   // ✅ HOME goes to trips
  { path: 'login', component: Login },
  { path: 'trips', component: TripList },
  { path: 'trips/add', component: TripAdd },
  { path: 'trips/edit/:tripCode', component: TripEdit },
  { path: '**', redirectTo: 'trips' }
];