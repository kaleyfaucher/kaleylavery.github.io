import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { TripData, Trip } from '../services/trip-data';

@Component({
  selector: 'app-trip-add',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './trip-add.html',
  styleUrl: './trip-add.css'
})
export class TripAdd {
  trip: Trip = {
    _id: '',
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: 0,
    image: '',
    description: ''
  };

  adding = false;
  error: string | null = null;

  constructor(private tripService: TripData, private router: Router) {}

  addTrip(): void {
    this.adding = true;
    this.error = null;

    // Don’t send _id from the form
    const payload = { ...this.trip };
    delete (payload as any)._id;

    this.tripService.addTrip(payload).subscribe({
      next: () => {
        this.adding = false;
        // go back to list so you can screenshot it
        this.router.navigate(['/trips']);
      },
      error: (err) => {
        console.log(err);
        this.error = 'Add failed. Check backend POST /api/trips.';
        this.adding = false;
      }
    });
  }
}