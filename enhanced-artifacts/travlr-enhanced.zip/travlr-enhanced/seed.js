const mongoose = require("mongoose");
require("./app_api/models/trips");

const Trip = mongoose.model("Trip");

const dbURI = "mongodb://127.0.0.1:27017/travlr";

mongoose.connect(dbURI);

const trips = [
  {
    code: "NYC",
    name: "New York City Getaway",
    length: "4 nights / 5 days",
    start: "2026-05-15",
    resort: "Manhattan Central Hotel",
    perPerson: 1299,
    image: "nyc.jpg",
    description: "Explore iconic landmarks, museums, Broadway, and world-class dining."
  },
  {
    code: "ROM",
    name: "Rome Adventure",
    length: "6 nights / 7 days",
    start: "2026-06-10",
    resort: "Historic City Inn",
    perPerson: 1799,
    image: "rome.jpg",
    description: "Guided tours of ancient sites, Vatican highlights, and local cuisine."
  },
  {
    code: "HNL",
    name: "Hawaii Beach Escape",
    length: "7 nights / 8 days",
    start: "2026-07-20",
    resort: "Oceanview Resort",
    perPerson: 2399,
    image: "hawaii.jpg",
    description: "Relax on the beach with snorkeling, hiking, and island excursions."
  }
];

const seedDB = async () => {
  try {
    await Trip.deleteMany({});
    await Trip.insertMany(trips);
    console.log("Database seeded successfully");
  } catch (err) {
    console.error(err);
  } finally {
    mongoose.connection.close();
  }
};

seedDB();
