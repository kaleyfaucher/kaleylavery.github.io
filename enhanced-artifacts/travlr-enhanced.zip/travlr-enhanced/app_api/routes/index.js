const express = require('express');
const router = express.Router();

const ctrlTrips = require('../controllers/trips');
const { requireAuth, login } = require('./auth');

// Login (mock creds: admin / travlr123)
router.post('/login', login);

// Public GET endpoints
router.get('/trips', ctrlTrips.tripsList);
router.get('/trips/:tripCode', ctrlTrips.tripsFindByCode);

// Protected admin endpoints (require JWT)
router.post('/trips', requireAuth, ctrlTrips.tripsAddTrip);
router.put('/trips/:id', requireAuth, ctrlTrips.tripsUpdateTrip);
router.delete('/trips/:id', requireAuth, ctrlTrips.tripsDeleteTrip);

module.exports = router;