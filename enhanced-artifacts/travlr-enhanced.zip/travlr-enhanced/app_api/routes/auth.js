const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'travlr-secret-key';

// Middleware to protect routes
function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const [type, token] = authHeader.split(' ');

  if (type !== 'Bearer' || !token) {
    return res.status(401).json({ message: 'Missing auth token' });
  }

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    return next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
}

// Mock login endpoint
function login(req, res) {
  const { username, password } = req.body || {};

  if (username === 'admin' && password === 'travlr123') {
    const token = jwt.sign(
      { username: 'admin', role: 'admin' },
      JWT_SECRET,
      { expiresIn: '1h' }
    );

    return res.status(200).json({ token });
  }

  return res.status(401).json({ message: 'Invalid credentials' });
}

module.exports = { requireAuth, login };