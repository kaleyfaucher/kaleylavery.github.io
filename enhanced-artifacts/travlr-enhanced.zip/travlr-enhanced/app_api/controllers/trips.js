const mongoose = require("mongoose");
const Trip = mongoose.model("Trip");

/**
 * GET /api/trips
 * Return all trips as JSON
 */
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).lean();
    return res.status(200).json(trips);
  } catch (err) {
    return res.status(500).json({
      message: "Error retrieving trips",
      error: err.message,
    });
  }
};

/**
 * GET /api/trips/:tripCode
 * Return a single trip (by code) as JSON
 */
const tripsFindByCode = async (req, res) => {
  try {
    const tripCode = req.params.tripCode;

    const trip = await Trip.findOne({ code: tripCode }).lean();
    if (!trip) {
      return res.status(404).json({ message: "Trip not found" });
    }

    return res.status(200).json(trip);
  } catch (err) {
    return res.status(500).json({
      message: "Error retrieving trip",
      error: err.message,
    });
  }
};

/**
 * POST /api/trips
 * Create a new trip
 */
const tripsAddTrip = async (req, res) => {
  try {
    // Accept both "start" or "startDate" just in case your form uses one or the other
    const startValue = req.body.start ?? req.body.startDate ?? "";

    const newTrip = {
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: startValue,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description,
    };

    // Basic required checks (keeps your API from silently failing)
    if (!newTrip.code || !newTrip.name) {
      return res.status(400).json({
        message: "code and name are required",
      });
    }

    const created = await Trip.create(newTrip);
    return res.status(201).json(created);
  } catch (err) {
    return res.status(500).json({
      message: "Error creating trip",
      error: err.message,
    });
  }
};

/**
 * PUT /api/trips/:id
 * Update a trip by Mongo _id
 */
const tripsUpdateTrip = async (req, res) => {
  try {
    const id = req.params.id;

    const startValue = req.body.start ?? req.body.startDate;

    const updates = {
      ...(req.body.code !== undefined ? { code: req.body.code } : {}),
      ...(req.body.name !== undefined ? { name: req.body.name } : {}),
      ...(req.body.length !== undefined ? { length: req.body.length } : {}),
      ...(startValue !== undefined ? { start: startValue } : {}),
      ...(req.body.resort !== undefined ? { resort: req.body.resort } : {}),
      ...(req.body.perPerson !== undefined ? { perPerson: req.body.perPerson } : {}),
      ...(req.body.image !== undefined ? { image: req.body.image } : {}),
      ...(req.body.description !== undefined ? { description: req.body.description } : {}),
    };

    const updated = await Trip.findByIdAndUpdate(id, updates, {
      new: true,
      runValidators: true,
    }).lean();

    if (!updated) {
      return res.status(404).json({ message: "Trip not found" });
    }

    return res.status(200).json(updated);
  } catch (err) {
    return res.status(500).json({
      message: "Error updating trip",
      error: err.message,
    });
  }
};

/**
 * DELETE /api/trips/:id
 * Delete a trip by Mongo _id
 */
const tripsDeleteTrip = async (req, res) => {
  try {
    const id = req.params.id;

    const deleted = await Trip.findByIdAndDelete(id).lean();
    if (!deleted) {
      return res.status(404).json({ message: "Trip not found" });
    }

    // Return something explicit so the client doesn't hang
    return res.status(200).json({ message: "Trip deleted", id });
  } catch (err) {
    return res.status(500).json({
      message: "Error deleting trip",
      error: err.message,
    });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip,
};