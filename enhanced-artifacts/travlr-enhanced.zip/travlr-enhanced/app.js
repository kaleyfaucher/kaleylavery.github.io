require("./app_api/models/db");

const express = require("express");
const path = require("path");

const apiRouter = require("./app_api/routes/index");

const app = express();
const PORT = 3000;

// Parse JSON + form bodies (REQUIRED for POST/PUT)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend files
app.use(express.static(path.join(__dirname, "public")));

// Mount REST API
app.use("/api", apiRouter);

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});