var express = require("express");
var router = express.Router();

var ctrlTravlr = require("../controllers/travlr");

/* GET pages */
router.get("/", ctrlTravlr.home);
router.get("/travel", ctrlTravlr.travel);
router.get("/rooms", ctrlTravlr.rooms);
router.get("/meals", ctrlTravlr.meals);

module.exports = router;
