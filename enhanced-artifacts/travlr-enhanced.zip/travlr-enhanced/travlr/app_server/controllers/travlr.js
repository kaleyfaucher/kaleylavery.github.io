const trips = require('../data/trips.json');
const rooms = require('../data/rooms.json');
const meals = require('../data/meals.json');

/* GET pages */
exports.home = (req, res) => {
  res.render("index", { title: "Travlr" });
};

exports.travel = (req, res) => {
  res.render("travel", {
    title: "Travel",
    trips: trips
  });
};

exports.rooms = (req, res) => {
  res.render("rooms", {
    title: "Rooms",
    rooms: rooms
  });
};


exports.meals = (req, res) => {
  res.render("meals", {
    title: "Meals",
    meals: meals
  });
};

