import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Trip {
  _id?: string;              // optional so POST doesn't require it
  code: string;
  name: string;
  length: string;
  start: string;             // API returns string dates
  resort: string;
  perPerson: number;
  image: string;
  description: string;
}

@Injectable({
  providedIn: 'root'
})
export class TripData {

  private apiUrl = '/api/trips';

  constructor(private http: HttpClient) {}

  getTrips() {
  return this.http.get<Trip[]>(this.apiUrl);
  }

  getTripByCode(tripCode: string) {
  return this.http.get<Trip>(`${this.apiUrl}/${tripCode}`);
  }

  addTrip(trip: Trip): Observable<Trip> {
    return this.http.post<Trip>(this.apiUrl, trip);
  }

  updateTrip(id: string, trip: Trip): Observable<Trip> {
    return this.http.put<Trip>(`${this.apiUrl}/${id}`, trip);
  }

  deleteTrip(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}