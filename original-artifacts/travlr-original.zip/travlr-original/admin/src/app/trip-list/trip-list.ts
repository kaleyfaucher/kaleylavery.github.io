import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TripData, Trip } from '../services/trip-data';
import { TripCardComponent } from '../trip-card/trip-card';

@Component({
  selector: 'app-trip-list',
  standalone: true,
  imports: [CommonModule, TripCardComponent],
  templateUrl: './trip-list.html',
  styleUrls: ['./trip-list.css']
})
export class TripList implements OnInit {
  trips: Trip[] = [];
  loading = true;
  error = '';

  constructor(private tripDataService: TripData) {}

  ngOnInit(): void {
    setTimeout(() => {
      this.tripDataService.getTrips().subscribe({
        next: (data) => {
          this.trips = data ?? [];
          this.loading = false;
        },
        error: (err) => {
          console.error('Trip load error:', err);
          this.error = `Failed to load trips. Status: ${err.status}`;
          this.loading = false;
        }
      });
    }, 0);
  }
}   