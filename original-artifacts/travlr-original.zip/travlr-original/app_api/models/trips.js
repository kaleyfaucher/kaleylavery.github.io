const mongoose = require("mongoose");

const tripSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true, trim: true },
  name: { type: String, required: true, trim: true },
  length: { type: String, required: true },
  start: { type: String, required: true },
  resort: { type: String, required: true },
  perPerson: { type: Number, required: true, min: 0 },
  image: { type: String, required: true },
  description: { type: String, required: true }
});

mongoose.model("Trip", tripSchema);
